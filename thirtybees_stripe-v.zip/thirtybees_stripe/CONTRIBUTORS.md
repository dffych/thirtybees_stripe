Stripe module for PrestaShop contributors (sorted alphabetically)
============================================

* **[Michael Dekker](https://github.com/firstred)**
    * Author of original module and maintainer